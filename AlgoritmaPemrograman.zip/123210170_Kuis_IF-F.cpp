#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <string>

using namespace std;

struct mahasiswa{
	int code;
	char nilaihuruf;
	string judul, penyanyi;
	float nilai;
};
	mahasiswa mhs[100];
	int js, pilih,pilih1, menu;
	char yn,y,n;
	
int main (){
	cout<<"===============================================================\n";
	cout<<"	Hello, User! Let's make our own music playlist!\n";
	cout<<"===============================================================\n";
	cout<<endl;
	cout<<" 1. Input Song Data\n";
	cout<<" 2. Output Song Data\n";
	cout<<" 3. Searching Song Data\n";
	cout<<" 4. Recursive\n";
	cout<<" 0. Exit\n";
		
	cout<<"Choose: ";
	cin>>pilih;
	
		if (pilih==1){
			cout<<endl;
			cout<<"How many data do you want enter? answer : ";
			cin>>js; cin.ignore();
		
			cout<<"Make sure the data you enter is sorted by the song code\n";
			cout<<endl;
		
			for (int i=0; i<js; i++){
        		cout<<"List Song " << i+1 << "\n";
        		cout<<"Song Code (4 character)\t: ";
        		cin>>mhs[i].code;
        		cout<<"Song Title\t: ";
        		cin >> mhs[i].judul;
        		cin.ignore();
        		cout << "Singer Name\t: ";
        		cin >> mhs[i].penyanyi;
        		cout << "Song Album\t: ";
        		cin >> mhs[i].nilai;
        		cout << endl;
        		//cin.ignore();
				/*
				if(mhs[i].nilai >= 75){
    				mhs[i].nilaihuruf = 'A';
				}
				else if(mhs[i].nilai >= 60){
					mhs[i].nilaihuruf = 'B';
				}
    			else if(mhs[i].nilai >= 40){
        			mhs[i].nilaihuruf = 'C';
				}
    			else if(mhs[i].nilai >= 20){
            		mhs[i].nilaihuruf = 'D';
				}
    			else if(mhs[i].nilai < 20){
        			mhs[i].nilaihuruf = 'E';
				}*/
				
				cout<<"Go back to main menu? (y/n) : ";
				cin>>yn; 
				
				if (yn==y){
					cout<<endl;
					cout<<" 1. Add Song Data\n";
					cout<<" 2. Output Song Data\n";
					cout<<" 3. Searching Song Data\n";
					cout<<" 4. Recursive\n";
					cout<<" 0. Exit\n";
					
					cout<<"Choose: ";
					cin>>pilih1;
					
						if (pilih1==1){
							
						}
						if (pilih1==2){
							
						}
						if (pilih1==3){
							
						}
						if (pilih1==4){
							
						}
						if (pilih1==0){
							exit(0);
						}
				}
				if (yn==n){
					exit(0);
				}
    		}
    		main();
		}
		
		else if (pilih == 2){
     		cout << "============================================================================\n";
    		cout << "\t\tDATA MAHASISWA SISTEM INFORMASI\n";
    		cout << "\t\t\tMATA KULIAH ALGORITMA\n";
    		cout << "============================================================================\n";
    		cout << "NIM\tNama\t\tKelas\tNilaiAngka\tNilaiHuruf\n";
    		cout << "============================================================================\n";
    		for (int i = 0;i < js;i++ ){
    			cout << mhs[i].code << "\t" << mhs[i].judul <<"\t\t"<< mhs[i].penyanyi <<"\t"<< mhs[i].nilai << "\t\t" << mhs[i].nilaihuruf << "\n";
    			cout << "============================================================================\n";
    			cin.ignore();
			}
    		system("pause");
    		system("cls");
    		main();
		}
		else if (pilih == 0){
    	exit(0);
		}
		
		else if (pilih==3){
			int menu;
			cout << "Menu Cari : \n";
			cout << "1. Sequential Search\n";
			cout << "2. Binary Search\n";
			cout << "3. Kembali\n";
			cout << "Pilih Menu : ";
			cin >> menu;
			if (menu == 3){
        	main();
   			}
				else if(menu == 1){ 
					bool found;
       	 			int cariNIM, i;
        			cout << "Anda memilih pencarian Sequential Search\n";
        			cout << "Masukan NIM yang dicari :"; cin >> cariNIM;
        			found = false;
        			i=0;
        			while ((i<js)&(!found)){
            			if (mhs[i].code == cariNIM)
            			found = true;
            			else
            			i = i+1;
        			}
        			if (found){
            			cout << "Data ditemukan pada indeks ke-";
            			for (int z=0; z < js; z++)
                			if(cariNIM == mhs[z].code){
                    		cout << z+1;
                		} 
						cout << "\n";

           				cout << "NIM\t : " << mhs[i].code << endl;
            			cout << "Nama\t : " << mhs[i].judul << endl;
            			cout << "Kelas\t : " << mhs[i].penyanyi << endl;
            			cout << "Nilai\t : " << mhs[i].nilai << endl;
            			cout << "Nilai Huruf\t: " << mhs[i].nilaihuruf << endl;
        			}
        			else{
            			cout << "Maaf data yang Anda cari tidak ada";
        			}
        			system("Pause");
        			main();

       			}
				else if (menu == 2){
				 	int i, cariNIM, j, k;
        			bool found;
        			cout << "Anda emilih pencarian binary search\n";
        			cout << "Masukan NIM yang dicari :"; cin >> cariNIM;
        			found = false;
        			i=0;
        			j=js;

        			while((!found)&(i <= j)){
            			k=(i+j)/2;
            			if(cariNIM==mhs[k].code){
                		found = true;
            			}
						else{
                		if(cariNIM < mhs[k].code)
                		j = k - 1;
                		else 
                		i = k + 1;
            			}
       				}
        			if(found){
            			cout << "NIM\t: " << mhs[k].code << endl;
            			cout << "Nama\t: " << mhs[k].judul << endl;
            			cout << "Kelas\t: " << mhs[k].penyanyi << endl;
            			cout << "Nilai\t: " << mhs[k].nilai << endl;
            			cout << "Nilai Huruf\t: " <<mhs[k].nilaihuruf << endl;
        			}
					else{
            			cout << "Maaf data yang Anda cari tidak ada";
        			}
				}
    			system("Pause");
    			system("cls");
    			main();
		}
		getch();
}

