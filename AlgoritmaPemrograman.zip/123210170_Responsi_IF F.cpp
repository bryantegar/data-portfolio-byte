#include <iostream>
#include <string.h>

using namespace std;

struct dataKgtn{
	string nama,bln;
	int tgl, thn;
};

int pil,i,j,bnykdata;
dataKgtn kgtn[100];
dataKgtn temp;

int main(){
	
		cout<<"-----------------------------"<<endl;
		cout<<"| Informasi Jadwal Kegiatan |"<<endl;
		cout<<"-----------------------------"<<endl;
		cout<<endl;
		
		cout<<"	MENU AWAL "<<endl;
		cout<<" 1. Input Data Kegiatan "<<endl;
		cout<<" 2. Lihat Data Kegiatan "<<endl;
		cout<<" 3. Cari Data Kegiatan "<<endl;
		cout<<" 4. Keluar "<<endl;
		cout<<" Pilihan : ";
		cin>>pil;
		system("cls");
		
		if (pil==1){
			
			cout<<endl;
			cout<<"Banyak Kegiatan : ";
			cin>>bnykdata; cin.ignore();	
			for (int i=0; i<bnykdata; i++){
				cout<<endl;
				cout<<"Kegiatan ke-"<<i+1<<endl;
				cout<<"Nama		: ";
				cin>>kgtn[i].nama;
				cin.ignore();
				cout<<"Tanggal		: ";
				cin>>kgtn[i].tgl;
				cout<<"Bulan		: ";
				cin>>kgtn[i].bln;
				cin.ignore();
				cout<<"Tahun		: ";
				cin>>kgtn[i].thn;
			}
		}
		
		if (pil==2){
			cout << "============================================================================\n";
    		cout << "\t\tData Kegiatan\n";
    		cout << "============================================================================\n";
    		cout << "Nama\tTanggal\t\tBulan\tTahun\n";
    		cout << "============================================================================\n";
    			for (int i=0; i<bnykdata; i++){
    				cout << kgtn[i].nama<<"\t"<<kgtn[i].tgl<<"\t\t"<<kgtn[i].bln<<"\t"<<kgtn[i].thn<<"\n";
    				cout << "============================================================================\n";
    				cin.ignore();
				}
    			system("pause");
    			system("cls");
    			main();
		}
		if (pil==3){

			int menu;
			cout<<"-----------------------------------------\n";
			cout<<"\t\tCari Data Kegiatan\n";
			cout<<"-----------------------------------------\n";
			cout << "1. Sequential Search\n";
			cout << "2. Kembali\n";
			cout << "Pilih Menu : ";
			cin >> menu;
			if (menu==1){
        	main();
   			}
				else if(menu == 1){ 
					bool found;
       	 			int cari_data, i;
        			cout << "Anda memilih pencarian Sequential Search\n";
        			cout << "Masukan data kegiatan dengan tanggal :"; cin >> cari_data;
        			found = false;
        			i=0;
        			while ((i<bnykdata)&(!found)){
            			if (kgtn[i].tgl == cari_data)
            			found = true;
            			else
            			i = i+1;
        			}
        			if (found){
            			cout << "Data ditemukan pada indeks ke-";
            			for (int z=0; z<bnykdata; z++)
                			if(cari_data == kgtn[z].tgl){
                    		cout << z+1;
                		} 
						cout<<"\n";

           				cout<<"Nama\t :"<<kgtn[i].nama << endl;
            			cout<<"Tanggal\t : "<<kgtn[i].tgl << endl;
            			cout<<"Bulan\t : " <<kgtn[i].bln << endl;
            			cout<<"Tahun\t : " <<kgtn[i].thn << endl;
            			
        			}
        			else{
            			cout << "Maaf data yang Anda cari tidak ada";
        			}
        			system("Pause");
        			system("cls");
        			main();
				}	
		}
		
		else {
			exit(4);
		}
}
